# Debit & Credit Challenge — React + Vite + Tailwind

This project packages your **DebitCreditGame.tsx** into a ready-to-deploy site.

## Run locally (optional)
1) Install Node.js 18+.
2) Run:
```bash
npm install
npm run dev
```
Open the local URL that Vite prints.

## Build static files
```bash
npm run build
```
Static files will be in `dist/`. You can upload `dist/` anywhere (Netlify drag-and-drop, GitHub Pages via actions, etc.)

## Deploy on Netlify (recommended)
### Option A: Connect a repo (no local build needed)
1) Push these files to GitHub.
2) In Netlify, **Add new site → Import from Git** and pick your repo.
3) Build command: `npm run build` ; Publish directory: `dist`.
4) Netlify will build and give you a public URL like `https://...netlify.app`.

### Option B: Build locally then upload
1) `npm install && npm run build`
2) Drag the `dist` folder to Netlify (**Add new site → Deploy manually**).

## Deploy on GitHub Pages
Common approach is to use an action (e.g., `peaceiris/actions-gh-pages`) to publish the `dist` folder to `gh-pages` branch.

---

Tailwind is preconfigured; classes in your component work out of the box.
The project also installs `lucide-react` for the icons you used.
