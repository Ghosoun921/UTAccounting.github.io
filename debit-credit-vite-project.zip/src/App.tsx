import React from 'react'
import DebitCreditGame from './DebitCreditGame'

export default function App() {
  return <DebitCreditGame />
}
